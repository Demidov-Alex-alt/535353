file_name = "file.txt"

with open(file_name, "r") as file:
    content = file.read()

letter_count = sum(1 for char in content if char.isalpha())

word_count = len(content.split())

line_count = content.count('\n') + 1

print("Количество букв латинского алфавита:", letter_count)
print("Число слов:", word_count)
print("Число строк:", line_count)