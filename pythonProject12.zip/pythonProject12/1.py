def read_end(lines, file):
    if lines < 1 or not isinstance(lines, int):
        print("Количество строк должно быть положительным целым числом.")
        return

    try:
        with open(file, 'r') as f:
            all_lines = f.readlines()

            if len(all_lines) < lines:
                print("В файле меньше строк, чем запрошено.")
                return

            start_index = len(all_lines) - lines
            for line in all_lines[start_index:]:
                print(line.strip())
    except FileNotFoundError:
        print("Файл не найден.")


# тест
read_end(2, 'article.txt')
