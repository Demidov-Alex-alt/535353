def longest_words(file):
    with open(file, 'r') as f:
        words = f.read().split()
    max_length = len(max(words, key=len))
    longest = [word for word in words if len(word) == max_length]
    return longest


result = longest_words('article.txt')
print(result)
